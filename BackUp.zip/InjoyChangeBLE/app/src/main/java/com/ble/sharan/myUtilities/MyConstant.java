package com.ble.sharan.myUtilities;

/**
 * Created by brst-pc93 on 12/20/16.
 */

public class MyConstant
{

    public static final String DEVICE_ADDRESS = "device_address";
    public static final String IS_CONNECTED = "is_connected";
    public static final String IS_MANUAL_DISCONNECTED = "is_manual_disconnected";
}
